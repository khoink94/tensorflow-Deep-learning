import matplotlib.pyplot as plt
import numpy as np
import math
from sampleImage import sampleImage

def display_network(A, cols):
# This function visualizes filters in matrix A. Each column of A is a filter. We will reshape each column into a square image and visualizes on each cell of the visualization panel.
# cols: how many columns are there in the dislay. Default value is the squareroot of the number of columns in A.
# rows: how many rows are there in the dislay.

# Display a random matrix with a specified figure number and a grayscale

    fig, axes = plt.subplots(nrows = cols, ncols = cols)
    index = 0
    for i in range(A.shape[1]):
        img = axes[math.floor(index /5)][index % 5].imshow(A[:, i].reshape(8,8), figure = fig, cmap = 'gray', interpolation = 'nearest', aspect='auto' )
        index +=1

    plt.subplots_adjust(hspace = 0, wspace = 0)
    plt.show()
