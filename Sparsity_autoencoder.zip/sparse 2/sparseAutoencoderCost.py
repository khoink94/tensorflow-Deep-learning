# Sparse Autoencoder Cost
import numpy as np
import math
from scipy import optimize

def sparseAutoencoderCostandGradient(theta, visibleSize, hiddenSize, lamda, sparsityParam, beta, data):
# visibleSize: the number of input units (probably 64)
# hiddenSie: the number of hidden units (probably 25)
# lamda: weight decay parameter
# sparsityParam: the desired average activation for the hidden units ( denoted in the lecture) notes by the greek alphabet rho, which looks like 'p'
# beta: weight of sparisity penalty term
# data: our 64x10000 matrix containing the training data. so, data(:,i) is the i-th training example

# the input theta is a vector(because LBFGS optimazation function expects the parameters to be a vector)
# follows the notation convention of the lecture notes
    W1 = theta[0:hiddenSize*visibleSize].reshape((visibleSize,hiddenSize))
    W2 = theta[hiddenSize*visibleSize: 2*hiddenSize*visibleSize].reshape((hiddenSize,visibleSize))
    b1 = theta[2*hiddenSize*visibleSize: 2*hiddenSize*visibleSize + hiddenSize]
    b2 = theta[2*hiddenSize*visibleSize + hiddenSize :]
    #print W1.shape,W2.shape,b1.shape, b2.shape
# Cost and gradient variables (your code needs to compute these value)
# Here, we initialize them to zeros

    cost = 0
    W1grad = np.zeros((W1.shape))
    W2grad = np.zeros((W2.shape))
    b1grad = np.zeros((b1.shape))
    b2grad = np.zeros((b2.shape))

#----------------------------Your code here-----------
# Instructions: Compute the cost/ optimazation objective J_sparse(W,b) for the Sparse Autoencoder
# W1grad, W2grad, b1grad, b2grad should be computed using backpropagation
# note that W1grad, W2grad, b1, b2 has the same dimension as W1, W2, b1, b2
# Your code should be set W1grad to be the partial derivate of J_spare(W, b) with respect to W1
# I.e., W1grad(i,j) should be the partial derivative of J_sparse(W,b) with respect to the input parameter W1(i,j).  Thus, W1grad should be equal to the term [(1/m)]\delta W**{(1)} + \lamda W**{(1)} in the last block of pseudo-code in 2.2
# Stated differently, if we were using batch gradient descent to optimize the parameters,
# the gradient descent update to W1 would be W1 := W1 - alpha * W1grad, and similarly for W2, b1, b2


# print W1.shape, W2.shape, b1.shape, b2.shape
# feedforward evolution
    a1 = data
    a2 = sigmoid(np.dot(a1, W1) + b1)
    a3 = sigmoid(np.dot(a2, W2) + b2)
    #print a1.shape,a2.shape,a3.shape
    
# Squared Error cost

    # weight decay term or regularization cost
    regularization_cost1 = np.dot(W1.ravel(), W1.ravel())
    regularization_cost2 = np.dot(W2.ravel(), W2.ravel())
    regularization_cost = regularization_cost1 + regularization_cost2
    
    # Sparsity cost term
    # average activation value for hidden units
    #a = np.dot(a1.T,a2)
    #print a.shape
    #pHat = np.sum(np.dot(a1.T, a2) ,axis =0) / a1.shape[0]
    pHat = np.sum(a2, axis = 0) / a1.shape[0]
    #print pHat
    # Replicate sparsity Param p into a column vector
    p = np.tile(sparsityParam, hiddenSize)
    #print p.shape
    # spasity cost

    sparsityCost = np.sum(p * np.log(p / pHat)+ (1.0 - p) * np.log((1.0 - p) / (1.0 - pHat)))
    
    #print sparsityCost
    
    # Cost
    cost = np.dot((a3 - a1).ravel(), (a3 - a1).ravel())/(a1.shape[0] * 2.0 ) + lamda * regularization_cost / 2.0 + beta *sparsityCost
    # delta2 is a matrix of delta term for the hidden layer
    # delta3 is a matrix of delta term for output layer

    delta3 = (a3 - a1) * a3 * (1.0 - a3)
    #    print delta3.shape
    #    print (a2*(1-a2)).shape
    # vector pHat is a vector i collums so i will replicate it into a matrix m rows and i collums with m is the numbers of training set
    #delta2pHat = np.sum(np.repeat(pHat, a1.shape[0]).reshape([a1.shape[0], hiddenSize]), axis =0 ) / a1.shape[0]
        #delta2p = np.tile(sparsityParam, hiddenSize)
    #print delta2p
    #delta2 = (np.dot(delta3,W2.T) + beta * (-delta2p/delta2pHat + (1 - delta2p) / (1 - delta2pHat)))  * a2 * (1-a2)
    delta2 = (np.dot(delta3, W2.T) + beta * (-p / pHat + (1.0 - p) / (1.0 - pHat)))  * a2 * (1.0 - a2)

    # deltaW1 = delta2()*transpose of a{1}
                        
    deltaW1 = np.dot(a1.T, delta2 )
    deltaW2 = np.dot(a2.T, delta3 )

    # W1grad = 1/m*deltaW1 + lamda*W1
    
    W1grad = deltaW1/a1.shape[0] + lamda * W1
    W2grad = deltaW2/a1.shape[0] + lamda * W2

    # now we will calculate bias gradient term
    
    deltab1 = np.sum(delta2, axis = 0)
    deltab2 = np.sum(delta3, axis = 0)
    
    # b1grad = 1/m *deltab1
    
    b1grad = deltab1/a1.shape[0]
    b2grad = deltab2/a1.shape[0]
#-------------------------------------------------------------------
# After computing the cost and gradient, we will convert the gradients back
# to a vector format (suitable for minFunc).  Specifically, we will unroll
# your gradient matrices into a vector.

    grad = np.concatenate((W1grad.flatten(), W2grad.flatten(), b1grad.flatten(), b2grad.flatten()))
    
    return cost, grad


#-------------------------------------------------------------------
# Here's an implementation of the sigmoid function, which you may find useful
# in your computation of the costs and the gradients.  This inputs a (row or column) vector (say (z1, z2, z3)) and returns (f(z1), f(z2), f(z3)).


def sigmoid(x):
    sigm = 1 / (1 + np.exp(-x))
    return sigm

def sparseAutoencoderCost(theta, visibleSize, hiddenSize, lamda, sparsityParam, beta, data):
    return sparseAutoencoderCostandGradient(theta, visibleSize, hiddenSize, lamda, sparsityParam, beta, data)[0]
