import math
import numpy

def initializeParameters(hiddenSize, visibleSize):

# Initialize parameters randomly based on layer sizes.
    r = math.sqrt(6)/math.sqrt(hiddenSize + visibleSize + 1) #we'll choose weights uniformly from the interval [-r, r]
    W1 = numpy.random.rand(visibleSize, hiddenSize)* 2 * r - r
    W2 = numpy.random.rand(hiddenSize, visibleSize)* 2 * r - r
    b1 = numpy.zeros((hiddenSize, 1))
    b2 = numpy.zeros((visibleSize, 1))

# Convert weights and bias gradients to the vector form.
# This step will unroll (flatten and concatenate together) all
# Your parameters into a vector, which can then be used with minFunc. (L-BFGS algorithms).

    theta = numpy.concatenate((W1.flatten(), W2.flatten(), b1.flatten(), b2.flatten()))
    return theta
