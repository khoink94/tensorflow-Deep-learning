import numpy as np
import math
def computeNumericalGradient(func, theta):

# numgrad = computeNumericalGradient(J, theta)
# theta: a vector of parameters
# J: a function that outputs a real-number. Calling y = J(theta) will return the function value at theta
# Initialize numgrad with zeros
    numgrad = np.zeros(theta.shape)

#--------------Your code here---------------
# Instruction:
# Implement numerical gradient checking, and return the result in numgrad
# Section 2.3 in lecture notes
# You should write code so that numgrad(i) is the numerical approximation to the partial derivative of K with respect to the i-th input argument, evaluated at theta.
# I.e., numgrad(i) should be the approximately the partial derivative of J with respect to theta(i)

# hint: you will propably want to compute the elements of numgrad one at a time

    EPSILON = 10 ** (-4)
    
    for i in xrange(theta.size):
        basicVector = np.zeros((theta.shape[0],1)).flatten()
        basicVector[i] = 1
        #print basicVector
        thetaPlus = theta + EPSILON * basicVector
        thetaMinus = theta - EPSILON * basicVector
        valuePlus, plus = func(thetaPlus)
        valueMinus, minus = func(thetaMinus)
        numgrad[i] = (valuePlus - valueMinus) / (2 * EPSILON)
    # print numgrad[i]
    return numgrad
#--------------------------------------------

#    for i in xrange(theta.size):
    # temporarily save the value
    #       theta_i = theta[i]
        # temporarily increase the value
        #   theta[i] = theta_i + EPSILON
        #val_plus = func(theta)
        # temporarily decrease the value
        # theta[i] = theta_i - EPSILON
        #val_minus = func(theta)
        # compute numerical gradient
        # numgrad[i] = (val_plus - val_minus) / (EPSILON * 2)
        # restore theta
        #theta[i] = theta_i
    
#  return numgrad
