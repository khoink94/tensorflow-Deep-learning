import scipy
import scipy.io
import numpy as np

def sampleImage():
# Return 10000 patchs for training

    IMAGES = scipy.io.loadmat('IMAGES.mat')
    patchsize = 8
    numpatches = 10000

# Initial patches with zeros. Your code will fill in this matrix-- one column per patch, 10000 columns

    patches = np.zeros(( numpatches, patchsize * patchsize))


#----------------Your code here-----------
# Instructions: Fill in the variable called patches using data from IMAGES

# IMAGEs is a 3D array containing 10 images
# For instance, IMAGES(:, :, 6) is a 512x512 array containing the 6th image and you can type imagesc(IMAGES(:, : , 6), colormap gray) (MATLAB) to visualize it.
# As a second example, IMAGES(21:30, 21:30, 1) is an image patch corresponding to the pixels in the block (21, 21) to (30, 30) of image 1
    imageArray = IMAGES['IMAGES']

    for i in xrange(numpatches):
        # Choose a random Images from IMAGES
        randomImage = np.random.randint(0, 9)
        # Get size of images
        height, weight = imageArray[: , :, randomImage].shape
        # Get a image patch with size patchsize * patchsize from image
        x = np.random.randint(0, height - patchsize)
        y = np.random.randint(0, weight - patchsize)
        data = imageArray[x:x + patchsize, y:y + patchsize, randomImage]
        data = data.flatten()
        # copy data to matrix
        np.copyto(dst = patches[i, :], src = data.reshape(1, patchsize * patchsize))


#-----------------------------------------------
# For the autoencoder to work well we need to normalie the data
# Specifially, since the output of the network is bounded between [0,1] due to the sigmoid activation function, we have to make sure the range of pixel values is also bounded between [0,1]

    patches = normalizeData(patches)
    return patches

#-------------------------------------
def normalizeData(patches):
# Squash data to [0.1, 0.9] since we use sigmoid as the activation function in the output layer
# Remove DC (mean of images)

    patches = patches - np.mean(patches)
# Remove DC (mean of images).
#   mean = np.mean(patches, axis=1)
#   patches -= mean[:, np.newaxis]
    

# Truncate to +/- 3 standard deviations and scale to -1 to 1
#pstd = 3 * np.std(patches[:], axis = 1)
#    pstd = pstd[:, np.newaxis]
#   patches = np.maximum(np.minimum(patches, pstd), -pstd) / pstd

    pstd = 3 * np.std(patches)
    dataset = np.maximum(np.minimum(patches, pstd), -pstd) /pstd
# Rescale from [-1, 1] to [0.1 , 0.9]
    patches = (patches + 1) * 0.4 + 0.1
    return patches




