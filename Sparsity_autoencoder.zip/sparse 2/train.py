# This is excercise of sparse autoencoder course in Stanford University
import numpy as np
import math
from scipy.optimize import fmin_l_bfgs_b, minimize
from sampleImage import sampleImage
from display_network import display_network
from initializeParameters import initializeParameters
from sparseAutoencoderCost import sparseAutoencoderCost, sparseAutoencoderCostandGradient
from checkNumericalGradient import checkNumericalGradient
from computeNumericalGradient import computeNumericalGradient

#======================
# Step 0: Here we provide the relevant parameters values that will allow your sparse autoencoder to get good filters;

visibleSize = 8 * 8 # number of input units
hiddenSize = 25     # number of hidden units
sparsityParam = 0.01 # desired average activation of the hidden units. this looks like a lower-case p in the lecture notes
lamda = 0.0001     # weight decay parameter
beta = 3           # weight of sparsity penalty term

#-------------------------
# Step 1: Implement sampleImages

# After implementing sampleImage, the display_network commond should dislay a random sample of a lot of patches from the dataset


patches = sampleImage()

#display_network(patches, 2)

# Obtain random parameters theta
theta = initializeParameters(hiddenSize, visibleSize)
#print theta

#------------------------------
# Step 2: Implement sparseAutoencoderCost

# You can implement all of the component (squared error cost, weight decay term, sparsity penalty) in the cost function at once, but it may be easier to do it step-by-step and run gradient checking (see step 3) after each step. We suggest implement the sparseAutoencoderCost function using the following steps:

# a) Implement forward propagation in your neural network, and implement the squared error term of the cost function. Implement backpropagation to compute the derivatives. Then (using lamda = beta= 0) , run gradient checking to verify that the calculations corresponding to the squared error cost term are correct.
# b) add in the weight decay term (in both the cost function and the derivative calculations), then re-run gradient checking to verify correctness.
# c) Add in the sparsity penalty term, then re-run gradient checking to verify correctness.

cost,grad = sparseAutoencoderCostandGradient(theta, visibleSize, hiddenSize, lamda, sparsityParam, beta,patches)

print cost,grad

#--------------------------------------------
# Step 3: Gradient checking
# hint: if you are debugging your code, performing gradient checking on smaller models and smaller training sets (e.g. using only 10 training examples and 1-2 hidden units) may speed things up
# First, lets make sure your numerical gradient computation is correct for a simple function. After you have implemented computeNumericalGradient.py, run the following:

#checkNumericalGradient()

# Now we can use it to check your cost function and derivative calculations for the sparse autoencoder.

func_sparseAutoencoderCost = lambda args : sparseAutoencoderCostandGradient(args, visibleSize, hiddenSize, lamda, sparsityParam, beta, patches)
#numgrad = computeNumericalGradient(func_sparseAutoencoderCost, theta)

# Use this to visually compare the gradients side by side

#print numgrad, grad

# Compare numerically computed gradients with the ones obtained from backpropagation

#diff = np.linalg.norm(numgrad - grad) / np.linalg.norm(numgrad + grad)
#print diff
# should be small. In our implementation, these values are usually less than 1e -9.
# When you got this working, Cogratulation!

#-------------------------------------------------
# Step 4: After verifying that your implementation of sparseAutoencoderCost is correct, You can start training your sparse autoencoder with optimazation L-BFGS
#Randomly initialize the parameters
theta = initializeParameters(hiddenSize, visibleSize)

#res= fmin_l_bfgs_b(func_sparseAutoencoderCost, theta)
func = (visibleSize, hiddenSize, lamda, sparsityParam, beta, patches)
res = minimize(sparseAutoencoderCostandGradient, x0 = theta, args = func, method = 'L-BFGS-B', jac=True, options={'maxiter': 800, 'disp': True})
#-----------------------------------------------
# Step 5: Visualization

optW1 = res.x[0 : visibleSize * hiddenSize].reshape((visibleSize, hiddenSize))
print optW1.shape
display_network(optW1, 5)
